#include <iostream>
#include <string>
#include <cmath>
#include <algorithm>

int binaryToDecimal(const std::string &binary) {
    int decimal = 0;
    int size = binary.size();
    for (int i = 0; i < size; ++i) {
        if (binary[size - 1 - i] == '1') {
            decimal += std::pow(2, i);
        }
    }
    return decimal;
}

std::string decimalToBinary(int decimal) {
    std::string binary;
    while (decimal > 0) {
        binary += (decimal % 2) ? '1' : '0';
        decimal /= 2;
    }
    std::reverse(binary.begin(), binary.end());
    return binary.empty() ? "0" : binary;
}

std::string binaryToHexadecimal(const std::string &binary) {
    int decimal = binaryToDecimal(binary);
    std::string hex;
    while (decimal > 0) {
        int remainder = decimal % 16;
        if (remainder < 10)
            hex += (remainder + '0');
        else
            hex += (remainder - 10 + 'A');
        decimal /= 16;
    }
    std::reverse(hex.begin(), hex.end());
    return hex.empty() ? "0" : hex;
}

std::string hexadecimalToBinary(const std::string &hex) {
    std::string binary;
    for (char hexDigit : hex) {
        switch (hexDigit) {
            case '0': binary += "0000"; break;
            case '1': binary += "0001"; break;
            case '2': binary += "0010"; break;
            case '3': binary += "0011"; break;
            case '4': binary += "0100"; break;
            case '5': binary += "0101"; break;
            case '6': binary += "0110"; break;
            case '7': binary += "0111"; break;
            case '8': binary += "1000"; break;
            case '9': binary += "1001"; break;
            case 'A': binary += "1010"; break;
            case 'B': binary += "1011"; break;
            case 'C': binary += "1100"; break;
            case 'D': binary += "1101"; break;
            case 'E': binary += "1110"; break;
            case 'F': binary += "1111"; break;
        }
    }
    return binary;
}

std::string decimalToHexadecimal(int decimal) {
    std::string hex;
    while (decimal > 0) {
        int remainder = decimal % 16;
        if (remainder < 10)
            hex += (remainder + '0');
        else
            hex += (remainder - 10 + 'A');
        decimal /= 16;
    }
    std::reverse(hex.begin(), hex.end());
    return hex.empty() ? "0" : hex;
}

int hexadecimalToDecimal(const std::string &hex) {
    int decimal = 0;
    int size = hex.size();
    for (int i = 0; i < size; ++i) {
        if (hex[size - 1 - i] >= '0' && hex[size - 1 - i] <= '9') {
            decimal += (hex[size - 1 - i] - '0') * std::pow(16, i);
        } else if (hex[size - 1 - i] >= 'A' && hex[size - 1 - i] <= 'F') {
            decimal += (hex[size - 1 - i] - 'A' + 10) * std::pow(16, i);
        }
    }
    return decimal;
}

int main() {
    int choice;
    while (true) {
        std::cout << "Base Conversion Menu:\n";
        std::cout << "1. Binary to Decimal\n";
        std::cout << "2. Decimal to Binary\n";
        std::cout << "3. Binary to Hexadecimal\n";
        std::cout << "4. Hexadecimal to Binary\n";
        std::cout << "5. Decimal to Hexadecimal\n";
        std::cout << "6. Hexadecimal to Decimal\n";
        std::cout << "7. Exit\n";
        std::cout << "Enter your choice: ";
        std::cin >> choice;

        if (choice == 7) {
            break;
        }

        std::string input;
        int decimalInput;
        switch (choice) {
            case 1:
                std::cout << "Enter binary number: ";
                std::cin >> input;
                std::cout << "Decimal: " << binaryToDecimal(input) << "\n";
                break;
            case 2:
                std::cout << "Enter decimal number: ";
                std::cin >> decimalInput;
                std::cout << "Binary: " << decimalToBinary(decimalInput) << "\n";
                break;
            case 3:
                std::cout << "Enter binary number: ";
                std::cin >> input;
                std::cout << "Hexadecimal: " << binaryToHexadecimal(input) << "\n";
                break;
            case 4:
                std::cout << "Enter hexadecimal number: ";
                std::cin >> input;
                std::cout << "Binary: " << hexadecimalToBinary(input) << "\n";
                break;
            case 5:
                std::cout << "Enter decimal number: ";
                std::cin >> decimalInput;
                std::cout << "Hexadecimal: " << decimalToHexadecimal(decimalInput) << "\n";
                break;
            case 6:
                std::cout << "Enter hexadecimal number: ";
                std::cin >> input;
                std::cout << "Decimal: " << hexadecimalToDecimal(input) << "\n";
                break;
            default:
                std::cout << "Invalid choice. Please try again.\n";
        }
    }

    return 0;
}
